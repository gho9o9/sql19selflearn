
/* *********************************************************************** */
/*   �X�P�[���A�E�g�\�ȃf�[�^�}�[�g�̓W�J��PowerBI�ɂ��f�[�^����.sql */
/* *********************************************************************** */

/* ------------------------------------------------------------------- */
/* ���O����                                                            */
/* ------------------------------------------------------------------- */

/* ===================================================== */
/* �O���e�[�u����`                                      */
/* ===================================================== */

/* ���� �菇 1. ���� */

USE [Demo];
GO
CREATE EXTERNAL FILE FORMAT My_CSV_Format
WITH (
    FORMAT_TYPE = DELIMITEDTEXT,
    FORMAT_OPTIONS (FIRST_ROW = 2,FIELD_TERMINATOR =','));
GO


/* ���� �菇 2. ���� */

USE [Demo];
GO
CREATE EXTERNAL TABLE StoragePool_Sales (
    MonthID Int,
    ItemID Int,
    LocationID Int,
    Sum_GrossMarginAmount decimal(10,2),
    Sum_Regular_Sales_Dollars decimal(10,2),
    Sum_Markdown_Sales_Dollars decimal(10,2),
    ScenarioID Int,
    ReportingPeriodID Int,
    Sum_Regular_Sales_Units Int,
    Sum_Markdown_Sales_Units Int
)
WITH (
        LOCATION='/RetailAnalysis/Sales.csv',
        DATA_SOURCE = SqlStoragePool,
        FILE_FORMAT = My_CSV_Format
);
GO
CREATE EXTERNAL TABLE StoragePool_Store (
    LocationID Int,
    [City Name] varchar(50),
    Territory char(2),
    PostalCode Int,
    OpenDate Datetime,
    SellingAreaSize Int,
    DistrictName varchar(50),
    Name varchar(50),
    StoreNumberName varchar(50),
    StoreNumber Int,
    City varchar(50),
    Chain varchar(50),
    DM varchar(50),
    DM_Pic varchar(100),
    DistrictID Int,
    [Open Month No] Int,
    [Open Month] char(3),
    [Open Year] Int,
    [Store Type] varchar(50)
)
WITH (
        LOCATION='/RetailAnalysis/Store.csv',
        DATA_SOURCE = SqlStoragePool,
        FILE_FORMAT = My_CSV_Format
);
GO
CREATE EXTERNAL TABLE StoragePool_Time (
    ReportingPeriodID Int,
    Period Int,
    FiscalYear Int,
    FiscalMonth char(3),
    Month Date
)
WITH (
        LOCATION='/RetailAnalysis/Time.csv',
        DATA_SOURCE = SqlStoragePool,
        FILE_FORMAT = My_CSV_Format
);
GO
CREATE EXTERNAL TABLE StoragePool_District (
    DistrictID Int,
    District varchar(50),
    DM varchar(50),	
    DM_Pic_fl varchar(100),	
    DM_Pic varchar(100),	
    BusinessUnitID Int,
    DMImage varchar(50)
)
WITH (
        LOCATION='/RetailAnalysis/District.csv',
        DATA_SOURCE = SqlStoragePool,
        FILE_FORMAT = My_CSV_Format
);
GO


/* ���� �菇 3. ���� */

USE [Demo];
GO
SELECT count(*) AS ROW_COUNT FROM StoragePool_Sales;
GO
SELECT count(*) AS ROW_COUNT FROM StoragePool_Store;
GO
SELECT count(*) AS ROW_COUNT FROM StoragePool_Time;
GO
SELECT count(*) AS ROW_COUNT FROM StoragePool_District;
GO


/* ------------------------------------------------------------------- */
/* �f�[�^�}�[�g�iData Pool�j�ւ̃e�[�u����`                           */
/* ------------------------------------------------------------------- */

/* ===================================================== */
/* �O���f�[�^�\�[�X�̒�`                                */
/* ===================================================== */

USE [Demo];
GO
CREATE EXTERNAL DATA SOURCE SqlDataPool
WITH (LOCATION = 'sqldatapool://controller-svc/default');
GO


/* ===================================================== */
/* �f�[�^�}�[�g�ւ̃e�[�u����`                          */
/* ===================================================== */

USE [Demo];
GO
CREATE EXTERNAL TABLE DataPool_Sales (
    MonthID Int,
    ItemID Int,
    LocationID Int,
    Sum_GrossMarginAmount decimal(10,2),
    Sum_Regular_Sales_Dollars decimal(10,2),
    Sum_Markdown_Sales_Dollars decimal(10,2),
    ScenarioID Int,
    ReportingPeriodID Int,
    Sum_Regular_Sales_Units Int,
    Sum_Markdown_Sales_Units Int
)
WITH (
        DATA_SOURCE = SqlDataPool,
        DISTRIBUTION = ROUND_ROBIN
);
GO
CREATE EXTERNAL TABLE DataPool_Store (
    LocationID Int,
    [City Name] varchar(50),
    Territory char(2),
    PostalCode Int,
    OpenDate Datetime,
    SellingAreaSize Int,
    DistrictName varchar(50),
    Name varchar(50),
    StoreNumberName varchar(50),
    StoreNumber Int,
    City varchar(50),
    Chain varchar(50),
    DM varchar(50),
    DM_Pic varchar(100),
    DistrictID Int,
    [Open Month No] Int,
    [Open Month] char(3),
    [Open Year] Int,
    [Store Type] varchar(50)
)
WITH (
        DATA_SOURCE = SqlDataPool,
        DISTRIBUTION = ROUND_ROBIN
);
GO
CREATE EXTERNAL TABLE DataPool_Time (
    ReportingPeriodID Int,
    Period Int,
    FiscalYear Int,
    FiscalMonth char(3),
    Month Date
)
WITH (
        DATA_SOURCE = SqlDataPool,
        DISTRIBUTION = ROUND_ROBIN
);
GO
CREATE EXTERNAL TABLE DataPool_District (
    DistrictID Int,
    District varchar(50),
    DM varchar(50),	
    DM_Pic_fl varchar(100),	
    DM_Pic varchar(100),	
    BusinessUnitID Int,
    DMImage varchar(50)
)
WITH (
        DATA_SOURCE = SqlDataPool,
        DISTRIBUTION = ROUND_ROBIN
);
GO


/* ------------------------------------------------------------------- */
/* �f�[�^���C�N����f�[�^�}�[�g�ւ̃f�[�^�A�g                          */
/* ------------------------------------------------------------------- */

/* ===================================================== */
/* �f�[�^���C�N����f�[�^�}�[�g�ւ̃f�[�^�A�g            */
/* ===================================================== */

/* ���� 1 �ڂ̃N�G�� ���� */

USE [Demo];
GO
INSERT INTO DataPool_Sales 
SELECT * FROM StoragePool_Sales;
GO
INSERT INTO DataPool_Store
SELECT * FROM StoragePool_Store;
GO
INSERT INTO DataPool_Time
SELECT * FROM StoragePool_Time;
GO
INSERT INTO DataPool_District
SELECT * FROM StoragePool_District;
GO


/* ���� 2 �ڂ̃N�G�� ���� */

USE [Demo];
GO
SELECT count(*) AS ROW_COUNT FROM DataPool_Sales;
GO
SELECT count(*) AS ROW_COUNT FROM DataPool_Store;
GO
SELECT count(*) AS ROW_COUNT FROM DataPool_Time;
GO
SELECT count(*) AS ROW_COUNT FROM DataPool_District;
GO


/* ===================================================== */
/* �{���F�f�[�^�}�[�g��`���Ă݂悤                      */
/* ===================================================== */

USE [Demo];
GO
EXECUTE('
    Use Demo;
    SELECT @@SERVERNAME AS SERVER,name AS TABLE_NAME
    FROM sys.tables WHERE name = ''DataPool_Sales'';'
) AT  DATA_SOURCE SqlDataPool;
GO


