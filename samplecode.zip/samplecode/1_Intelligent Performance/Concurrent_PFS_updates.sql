
/* ******************************************************************* */
/*   Concurrent_PFS_updates.sql                                        */
/* ******************************************************************* */

/* ------------------------------------------------------------------- */
/* [1] SQL Server 2017 �ȑO�̓���                                      */
/* ------------------------------------------------------------------- */

/* ============================================= */
/* tempdb �f�[�^�t�@�C�����̒���                 */
/* ============================================= */

USE tempdb;
GO
-- �f�[�^�t�@�C������ɂ���
DBCC SHRINKFILE (N'temp2', EMPTYFILE);
GO
-- �f�[�^�t�@�C�����폜����
ALTER DATABASE tempdb REMOVE FILE temp2;
GO
-- �f�[�^�t�@�C�����m�F����
SELECT DB_NAME(database_id) AS db_name, file_id, type_desc, name, physical_name 
FROM sys.master_files WHERE database_id = 2 AND type = 0;
GO


/* ============================================= */
/* �ҋ@���v���̃N���A                          */
/* ============================================= */

USE master;
GO
DBCC SQLPERF("sys.dm_os_wait_stats", CLEAR);
GO


/* ============================================= */
/* ���b�`�ҋ@�̔����󋵂��m�F                    */
/* ============================================= */

/* ���� �菇 1. ���� */

CREATE TABLE #Order_PFS(
  [Order Key] bigint IDENTITY(1,1) NOT NULL,
  [City Key] int NOT NULL,
  [Customer Key] int NOT NULL,
  [Stock Item Key] int NOT NULL,
  [Order Date Key] date NOT NULL,
  [Picked Date Key] date NULL,
  [Description] nvarchar(100) NOT NULL
);
DECLARE @i int = 0;
WHILE(@i < 10000)
BEGIN
  INSERT INTO #Order_PFS([City Key],[Customer Key],[Stock Item Key],[Order Date Key],[Picked Date Key],[Description]) VALUES(1,1,1,GETDATE(),GETDATE(),N'XXXXX');
  SET @i = @i + 1;
END;


/* ���� �菇 2. ���� */

USE master;
GO
SELECT
  er.session_id, er.wait_type, er.wait_resource,
  er.blocking_session_id, er.command, 
  SUBSTRING(st.text, (er.statement_start_offset/2)+1,   
    ((CASE er.statement_end_offset  
        WHEN -1 THEN DATALENGTH(st.text)  
        ELSE er.statement_end_offset  
      END - er.statement_start_offset)/2) + 1) AS statement_text
FROM sys.dm_exec_requests AS er
  CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st
WHERE er.wait_type like '%latch%';
GO


/* ============================================= */
/* �ҋ@�̓��v�����̎�                          */
/* ============================================= */

USE master;
GO
SELECT * FROM sys.dm_os_wait_stats WHERE wait_time_ms > 0 ORDER BY wait_time_ms desc;
GO


/* ------------------------------------------------------------------- */
/* [2] SQL Server 2019 �ȑO�̓���                                      */
/* ------------------------------------------------------------------- */

/* ============================================= */
/* tempdb �f�[�^�t�@�C�����̒���                 */
/* ============================================= */

USE tempdb;
GO
-- �f�[�^�t�@�C������ɂ���
DBCC SHRINKFILE (N'temp2', EMPTYFILE);
GO
-- �f�[�^�t�@�C�����폜����
ALTER DATABASE tempdb REMOVE FILE temp2
GO
-- �f�[�^�t�@�C�����m�F����
SELECT DB_NAME(database_id) AS db_name, file_id ,type_desc, name, physical_name 
FROM sys.master_files WHERE database_id = 2 AND type = 0
GO


/* ============================================= */
/* �ҋ@���v���̃N���A                          */
/* ============================================= */

USE master;
GO
DBCC SQLPERF("sys.dm_os_wait_stats", CLEAR);
GO


/* ============================================= */
/* ���b�`�ҋ@�̔����󋵂��m�F                    */
/* ============================================= */

/* ���� �菇 2. ���� */

USE master;
GO
SELECT
  er.session_id, er.wait_type, er.wait_resource,
  OBJECT_NAME(page_info.object_id, page_info.database_id) as object_name,
  er.blocking_session_id,er.command, 
  SUBSTRING(st.text, (er.statement_start_offset/2)+1,   
    ((CASE er.statement_end_offset  
        WHEN -1 THEN DATALENGTH(st.text)  
        ELSE er.statement_end_offset  
      END - er.statement_start_offset)/2) + 1) AS statement_text,
  page_info.database_id, page_info.file_id, page_info.page_id, page_info.object_id,
  page_info.index_id, page_info.page_type_desc
FROM sys.dm_exec_requests AS er
  CROSS APPLY sys.dm_exec_sql_text(er.sql_handle) AS st
  CROSS APPLY sys.fn_PageResCracker (er.page_resource) AS r
  CROSS APPLY
    sys.dm_db_page_info(r.db_id, r.file_id, r.page_id, 'DETAILED') AS page_info
WHERE er.wait_type like '%latch%';
GO


/* ============================================= */
/* �ҋ@�̓��v�����̎�                          */
/* ============================================= */

USE master;
GO
SELECT * FROM sys.dm_os_wait_stats WHERE wait_time_ms > 0 ORDER BY wait_time_ms desc;
GO


