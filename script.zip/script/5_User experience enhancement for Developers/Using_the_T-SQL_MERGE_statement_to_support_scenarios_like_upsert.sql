
/* *********************************************************************** */
/*   Using_the_T-SQL_MERGE_statement_to_support_scenarios_like_upsert.sql  */
/* *********************************************************************** */

/* ============================================= */
/* �m�[�h�ƃG�b�W���`����                      */
/* ============================================= */

USE WideWorldImporters;
GO
-- �m�[�h�e�[�u���̍쐬
CREATE TABLE Person  (ID int PRIMARY KEY, name varchar(100)) AS NODE;
CREATE TABLE Product (ID int PRIMARY KEY, name varchar(100)) AS NODE;
-- �G�b�W�e�[�u���̍쐬
CREATE TABLE Bought(bought_count int) AS EDGE;
GO


/* ============================================= */
/* �f�[�^��o�^����                              */
/* ============================================= */

USE WideWorldImporters;
GO
-- �m�[�h�e�[�u���ւ̃f�[�^�}��
INSERT INTO Person VALUES (1,'Taro');
INSERT INTO Person VALUES (2,'Jiro');
INSERT INTO Product VALUES (1,'PC');
INSERT INTO Product VALUES (2,'LAN cable');
INSERT INTO Product VALUES (3,'Keyboard');
GO
-- �G�b�W�e�[�u���ւ̃f�[�^�}��
INSERT INTO Bought VALUES ((SELECT $node_id FROM Person WHERE ID = 1), 
  (SELECT $node_id FROM Product WHERE ID = 3),1);
INSERT INTO Bought VALUES ((SELECT $node_id FROM Person WHERE ID = 2), 
  (SELECT $node_id FROM Product WHERE ID = 2),3);
GO
-- �f�[�^�}�����ʂ��m�F
SELECT Person.name AS PersonName, Product.name AS ProductName, Bought.bought_count
FROM Person, Product, Bought
WHERE MATCH(Person-(Bought)->Product);
GO


/* ============================================= */
/* �uBought�v�G�b�W�e�[�u����MERGE�����N�G������ */
/* ============================================= */

USE WideWorldImporters;
GO
-- UPSERT �̎��s
DECLARE @PersonID varchar(100) = 1  -- 'Taro'
DECLARE @ProductID varchar(100) = 3 -- 'Keyboard'
DECLARE @add_count int = 3
MERGE Bought
  USING (
   (SELECT @PersonID, @ProductID, @add_count) AS T (PersonID, ProductID, add_count)
      JOIN Person ON T.PersonID = Person.ID
      JOIN Product ON T.ProductID = Product.ID)
   ON MATCH (Person-(Bought)->Product)
WHEN MATCHED THEN
  UPDATE SET bought_count = bought_count + add_count
WHEN NOT MATCHED THEN
  INSERT ($from_id, $to_id, bought_count)
    VALUES (Person.$node_id, Product.$node_id, add_count);
GO
-- UPSERT �̎��s���ʂ��m�F
SELECT Person.name AS PersonName, Product.name AS ProductName, Bought.bought_count
FROM Person, Product, Bought
WHERE MATCH(Person-(Bought)->Product);
GO


