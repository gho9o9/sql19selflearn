
/* ******************************************************************* */
/*   New_graph_function-SHORTEST_PATH.sql                              */
/* ******************************************************************* */

/* ============================================= */
/* �m�[�h�ƃG�b�W���`����                      */
/* ============================================= */

USE WideWorldImporters;
GO
-- �m�[�h�e�[�u���̍쐬
CREATE TABLE Station (ID int PRIMARY KEY, name varchar(100)) AS NODE;
-- �G�b�W�e�[�u���̍쐬
CREATE TABLE NextTo AS EDGE;
GO


/* ============================================= */
/* �f�[�^��o�^����                              */
/* ============================================= */

USE WideWorldImporters;
GO
-- �m�[�h�e�[�u���ւ̃f�[�^�}��
INSERT INTO Station VALUES (1, 'Station1');
INSERT INTO Station VALUES (2, 'Station2');
INSERT INTO Station VALUES (3, 'Station3');
INSERT INTO Station VALUES (4, 'Station4');
INSERT INTO Station VALUES (5, 'Station5');
INSERT INTO Station VALUES (6, 'Station6');
GO
-- �G�b�W�e�[�u���ւ̃f�[�^�}��
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 1), 
  (SELECT $node_id FROM Station WHERE ID = 2));  
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 2), 
  (SELECT $node_id FROM Station WHERE ID = 3));
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 3), 
  (SELECT $node_id FROM Station WHERE ID = 4));
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 4), 
  (SELECT $node_id FROM Station WHERE ID = 5));
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 5), 
  (SELECT $node_id FROM Station WHERE ID = 6));
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 2), 
  (SELECT $node_id FROM Station WHERE ID = 5));
INSERT INTO NextTo VALUES ((SELECT $node_id FROM Station WHERE ID = 6), 
  (SELECT $node_id FROM Station WHERE ID = 1));
GO
-- �f�[�^�}�����ʂ��m�F
SELECT st1.name AS st1_name, st2.name AS st2_name
FROM Station AS st1, NextTo, Station AS st2
WHERE MATCH (st1-(NextTo)->st2);
GO


/* ============================================= */
/* �ŒZ�o�H���Ɖ��                            */
/* ============================================= */

USE WideWorldImporters;
GO
SELECT
  st1.name AS FromST,
  LAST_VALUE(st2.name) WITHIN GROUP (GRAPH PATH) AS ToST,
  STRING_AGG(st2.name, '->') WITHIN GROUP (GRAPH PATH) AS ShortestRoot
FROM
  Station AS st1,
  NextTo FOR PATH AS nt,
  Station FOR PATH AS st2
WHERE MATCH(SHORTEST_PATH(st1(-(nt)->st2)+)) AND st1.name = 'Station1'
GO


