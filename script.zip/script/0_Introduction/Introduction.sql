
/* ******************************************************************* */
/*   Introduction.sql                                                  */
/* ******************************************************************* */

/* ------------------------------------------------------------------- */
/* �T���v���f�[�^�x�[�X�̍쐬                                          */
/* ------------------------------------------------------------------- */

/* ============================================= */
/* WideWorldImporters �f�[�^�x�[�X��             */
/* WideWorldImportersDW �f�[�^�x�[�X�̍쐬       */
/* ============================================= */

USE master;
GO
-- �T���v���f�[�^�x�[�X�uWideWorldImporters�v�����X�g�A
RESTORE DATABASE WideWorldImporters
  FROM DISK = 'C:\work\WideWorldImporters-Full.bak'
  WITH MOVE 'WWI_Primary' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImporters.mdf',
       MOVE 'WWI_UserData' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImporters_UserData.ndf',
       MOVE 'WWI_Log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImporters.ldf',
       MOVE 'WWI_InMemory_Data_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImporters_InMemory_Data_1';
GO

-- �T���v���f�[�^�x�[�X�uWideWorldImportersDW�v�����X�g�A
RESTORE DATABASE WideWorldImportersDW
  FROM DISK = 'C:\work\WideWorldImportersDW-Full.bak'
  WITH MOVE 'WWI_Primary' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImportersDW.mdf',
       MOVE 'WWI_UserData' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImportersDW_UserData.ndf',
       MOVE 'WWI_Log' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImportersDW.ldf',
       MOVE 'WWIDW_InMemory_Data_1' TO 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\WideWorldImportersDW_InMemory_Data_1';
GO

-- ���X�g�A�����f�[�^�x�[�X�̑��݂��m�F
SELECT * FROM sys.databases WHERE name LIKE N'WideWorldImporters%';
GO


/* ============================================= */
/* WideWorldImportersDW �f�[�^�x�[�X�ւ̒ǉ���   */
/* �f�[�^�o�^                                    */
/* ============================================= */

USE WideWorldImportersDW;
GO
SELECT 'Fact.OrderHistory' AS TableName, COUNT(*) AS Count
  FROM Fact.OrderHistory;
GO
SELECT 'Fact.OrderHistoryExtended' AS TableName, COUNT(*) AS Count
  FROM Fact.OrderHistoryExtended;
GO


